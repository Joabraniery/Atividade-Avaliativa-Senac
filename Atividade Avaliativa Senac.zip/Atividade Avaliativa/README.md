Passo 1
    Criação do BD empresa, com tabela clientes.

Passo 2 
    Criação das pastas do modelo MVC juntos com as rotas.

Passo 3 
    Por ultimo, feito a conexão da aplicação com o banco de dados e realizados os testes.
